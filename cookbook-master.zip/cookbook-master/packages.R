# Add additional R packages you want to install to this R file.
# This is just an R file, so you must type a valid install.packages functional call.

# For example, uncomment the following line and type `sb reload requirements` to install
# the bigrquery package to ScienceBox.

# install.packages("bigrquery", repos = "http://cran.us.r-project.org")

install.packages("lattice")
