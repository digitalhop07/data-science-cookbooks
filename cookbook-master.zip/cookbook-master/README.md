# Data Science Cookbook
![Science Box](https://ghe.spotify.net/science-box/science-box-cookie/raw/master/science_box_logotype.png)

Recipes that walk you through how to complete common data science tasks.

Each recipe is written in **Problem**, **Solution**, **Discussion** format, ripping off O'Reilly's Cookbook books.

## Running the Recipes
To launch Jupyter Notebook and run the recipes, [install Science Box](https://docs.google.com/document/d/1dPI_zcBkDh8m3BRlipwPjX2TMxQa90BsxLHA7bZFwP4/edit#heading=h.3eenzfunbegf), clone this repo, navigate to it, and type this into your shell:

`$ sb jupyter notebook`

## Repo Contents
- `results`: where final analysis results live.
- `notebooks`: Jupyter notebooks are stored here.
- `notebooks/examples`: example notebooks contributed by the community.
- `src/sql`: SQL files used for data processing live here.
- `src/python`: python scripts (non-notebook) live here.
- `src/R`: R scripts (non-notebook)  live here.
- `data`: place to keep any local data used in the analysis (don't check data into repo).
- `Drakefile`: script to reproduce every step in your analysis using [drake](https://github.com/Factual/drake), a data workflow tool.
- `requirements.txt`: install additional python packages (Science Box ships with hundreds).
- `packages.R`: install additional R packages (Science Box ships with hundreds).
- `Dockerfile`: recipe to build docker image that powers Science Box, edit to install additional system software.
- `.sb`: metadata file required for `sb` command line tool to work.

<br>
<p align="center">
  <img src="https://ghe.spotify.net/science-box/science-box-cookie/raw/master/science_box_logo.png" alt="Science Box"/>
</p>
<br>
