library(bigrquery)
n <- readline(prompt="Enter Project to Execute Query: ")
query_exec(project = n, 
           query = "SELECT * FROM `nyc-tlc.yellow.trips` LIMIT 10", 
           use_legacy_sql = FALSE)
