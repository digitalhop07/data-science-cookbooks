# Data Science Lifecycle @ Spotify

An overview of the work, tools, and methods used by data scientists at Spotify.


## Tools

Lorem ipsum. 


### 1. Data Instrumentation
Partner with Engineers to identify the necessarily signals to capture within the client.



### 2. Metric Setting
Partner with business stakeholders to identify metrics that will inform business/product outcomes and performance, and produce or source these metrics in/from BigQuery.



### 3. Data Pipelines
Query large datasets on a scheduled basis. Pipelines output datasets that are used by data scientists for analysis or in dashboards.

+ [BigQuery Runner](). Use BQ-Runner to schedule queries in BigQuery. 
    + Test a BQ-Runner pipeline locally
    + Test a BQ-Runner pipeline from Github

+ [Py Runner](). Use Py-Runner to schedule Python scripts. 



### 4. Data Preparation
Query, munge and transform data into a format that can be visualized or analyzed, resulting in analyst or visualization-friendly datasets.

+ [BQT](https://ghe.spotify.net/science-box/bqt/tree/master/bqt). BQT is a Spotify-developed tool that allows data scientists to seamlessly manage common tasks in BigQuery. 
    + Query BigQuery Tables
    + Manipulate BigQuery Tables

+ [Pandas GBQ] GBQ is an external library that allows users to query BigQuery tables and load dataframes to BigQuery. 
    + Load a dataframe to BigQuery
    + Output a BigQuery query to a dataframe

+ [Pandas]() Pandas is a library that makes data transformation within Python easy.
    + Group by a column and calculate metrics
    + Append two dataframes
    + Merge two dataframes
    + Apply a function based on one or more columns
    + Convert a dictionary to a dataframe
    
+ [APIs: Requests]() Requests is a Python library that allows users to retrieve information from APIs. 
    + ... 
    + Paginate the response from an API call



### 5. Experimentation
Test changes in products or business actions to determine whether they can improve business outcomes.



### 6. Modeling & Machine Learning
Apply supervised models to predict future outcomes or unsupervised models to understand trends.



### 7. Quality & Peer Review
A collaborative process to ensure data, code and outputs within an analysis are logical and accurate.



### 8. Data Visualization
Convert data into a visual form that conveys information to its viewers.

+ [Chartify]()


### 9. Dashboards
Scheduled, interactive reports that provide insights to data scientists and business stakeholders.



### 10. Qualitative Studies
Partner with User Research to analyze surveys and/or supplement our insights with our users’ perspectives.



### 11. Insights Production
Transform analysis and visualizations into written form, providing business context and recommendations to stakeholders.



