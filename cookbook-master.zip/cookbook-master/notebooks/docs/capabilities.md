#### Data Science Lifecycle @ Spotify
An overview of the work, tools, and methods used by data scientists at Spotify.

<br>

# Capabilities

We have deconstrucuted the data science lifecycle into independent groups of activities, which we refer to as Capabilities. 
Any data science analysis at Spotify uses one or more capability; however, it is rare that all capabilities are used within a single analysis. <br>

Capabilities fall within three groups: 

- __Data Management__: the process of extracting and transforming data into a format that can be analyzed.
- __Stats & Analysis__: applying analytical methods to process data into a format that can be synthesized for insights.
- __Insights Production__: the process of extracting business value-added information from data, research and analysis. 



## Data Management

### 1. Data Instrumentation
Partner with Engineers to identify the necessarily signals to capture within the client.

- [Tools]()
- [Methodology]()
- [Use Cases]()
- [Documentation]()


### 2. Metric Setting
Partner with business stakeholders to identify metrics that will inform business/product outcomes and performance, and produce or source these metrics in/from BigQuery.

- [Tools]()
- [Methodology]()
- [Use Cases]()
- [Documentation]()



### 3. Data Pipelines
Query large datasets on a scheduled basis. Pipelines output datasets that are used by data scientists for analysis or in dashboards.

- [Tools]()
- [Methodology]()
- [Use Cases]()
- [Documentation]()



### 4. Data Querying
Using SQL to query data, transforming it into a form that can be further transformed or analyzed.

- [Tools]()
- [Methodology]()
- [Use Cases]()
- [Documentation]()




### 5. Data Transformation
Query, munge and transform data into a format that can be visualized or analyzed, resulting in analyst or visualization-friendly datasets.

- [Tools]()
- [Methodology]()
- [Use Cases]()
- [Documentation]()


<br>

## Stats & Analysis


### 6. Data Analysis
Deterministic transformations of data oriented towards a business-oriented outcome. 
Said differently, the process of preparing data to produce insights. 

- [Tools]()
- [Methodology]()
- [Use Cases]()
- [Documentation]()


### 7. Experimentation
Test changes in products or business actions to determine whether they can improve business outcomes.

- [Tools]()
- [Methodology]()
- [Use Cases]()
- [Documentation]()



### 8. Modeling & Machine Learning
Apply supervised models to predict future outcomes or unsupervised models to understand trends.

- [Tools]()
- [Methodology]()
- [Use Cases]()
- [Documentation]()



### 9. Quality & Peer Review
A collaborative process to ensure data, code and outputs within an analysis are logical and accurate.

- [Tools]()
- [Methodology]()
- [Use Cases]()
- [Documentation]()


<br>

## Insights Production


### 10. Data Visualization
Convert data into a visual form that conveys information to its viewers.

- [Tools]()
- [Methodology]()
- [Use Cases]()
- [Documentation]()



### 11. Dashboards
Scheduled, interactive reports that provide insights to data scientists and business stakeholders.

- [Tools]()
- [Methodology]()
- [Use Cases]()
- [Documentation]()



### 12. Qualitative Studies
Partner with User Research to analyze surveys and/or supplement our insights with our users’ perspectives.

- [Tools]()
- [Methodology]()
- [Use Cases]()
- [Documentation]()



### 13. Insights Communication
Transform analysis and visualizations into written form, providing business context and recommendations to stakeholders.

- [Tools]()
- [Methodology]()
- [Use Cases]()
- [Documentation]()



