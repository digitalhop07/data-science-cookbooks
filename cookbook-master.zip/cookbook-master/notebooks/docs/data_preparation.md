#### Data Science Lifecycle @ Spotify
An overview of the work, tools, and methods used by data scientists at Spotify.

<br><br>

# Data Preparation
Query, munge and transform data into a format that can be visualized or analyzed, resulting in analyst or visualization-friendly datasets.

<br>


## Tools

### [BQT](https://ghe.spotify.net/science-box/bqt/tree/master/bqt)
BQT is a Spotify-developed tool that allows data scientists to seamlessly manage common tasks in BigQuery. 
    + Query BigQuery Tables
    + Manipulate BigQuery Tables


### [Pandas](https://pandas.pydata.org/pandas-docs/stable/)
Pandas is a library that makes data transformation within Python easy.
    + Group by a column and calculate metrics
    + Append two dataframes
    + Merge two dataframes
    + Apply a function based on one or more columns
    + Convert a dictionary to a dataframe


### [Pandas GBQ](https://pandas.pydata.org/pandas-docs/stable/reference/api/pandas.read_gbq.html)
GBQ is an external library that allows users to query BigQuery tables and load dataframes to BigQuery. 
    + Load a dataframe to BigQuery
    + Output a BigQuery query to a dataframe


### [APIs: Requests](https://pypi.org/project/requests/2.7.0/)
Requests is a Python library that allows users to retrieve information from APIs. 
    + ... 
    + Paginate the response from an API call


<br><br>

## Methodology

Lorem ipsum. 


<br><br>

## Use Cases

Lorem ipsum.


<br><br>

## Common Tasks

__Calculating dataframes__
+ Profiling pandas dataframe
+ Calculating metrics from pandas dataframe
    + Distinct count
    + Window functions
    + Cumulative metrics
+ Calculating value from function
+ Calculating value from multiple columns


__Joining dataframes__
+ Joining pandas dataframe


__Transforming dataframes__
+ Grouping pandas dataframe
+ Pivoting dataframes


<br><br>

## Documentation

+ [Pandas Cheat Sheet: Wrangling Data](https://pandas.pydata.org/Pandas_Cheat_Sheet.pdf)
+ [DataCamp: Pandas](https://www.datacamp.com/community/blog/python-pandas-cheat-sheet)
